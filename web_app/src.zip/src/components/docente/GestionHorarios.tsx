import { useState, useEffect } from 'react';
import Modal from '../Modal';

export default function GestionHorarios() {
  const [horarios, setHorarios] = useState<string[]>([]);
  
  const [fecha, setFecha] = useState<string>('');
  const [horaInicio, setHoraInicio] = useState<string>('');
  const [horaFin, setHoraFin] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    const horariosGuardados = localStorage.getItem('horarios_docente');
    if (horariosGuardados) {
      setHorarios(JSON.parse(horariosGuardados));
    } else {
      setHorarios(['2023-11-15 de 10:00 a 12:00', '2023-11-16 de 14:00 a 15:00']);
    }
  }, []);

  const agregarHorario = () => {
    if (!fecha || !horaInicio || !horaFin) {
      alert("Por favor, completa todos los campos.");
      return;
    }

    const inicio = parseInt(horaInicio.replace(':', ''));
    const fin = parseInt(horaFin.replace(':', ''));

    if (fin <= inicio) {
      alert("La hora de fin debe ser posterior a la hora de inicio.");
      return;
    }

    const nuevoHorarioFormateado = `${fecha} de ${horaInicio} a ${horaFin}`;
    const nuevaLista = [...horarios, nuevoHorarioFormateado];
    
    setHorarios(nuevaLista);
    localStorage.setItem('horarios_docente', JSON.stringify(nuevaLista));
    setFecha('');
    setHoraInicio('');
    setHoraFin('');
    setIsModalOpen(false);
  };

  const eliminarHorario = (index: number) => {
    const nuevaLista = horarios.filter((_, i) => i !== index);
    setHorarios(nuevaLista);
    localStorage.setItem('horarios_docente', JSON.stringify(nuevaLista));
  };

  return (
    <section className="dashboard-card-panel">
      <div className="header-con-boton">
        <div>
          <h3>Mis Horarios de Disponibilidad</h3>
        </div>
        <button className="btn-agregar-horario" onClick={() => setIsModalOpen(true)}> + Agregar Franja</button>
      </div>

      <div className="horarios-lista">
        {horarios.length > 0 ? (
          <ul>
            {horarios.map((h, index) => (
              <li key={index} className="horario-item">
                <span className="horario-texto">
                  <i className="bi bi-clock"></i> {h}
                </span>
                <button className="btn-eliminar-horario" onClick={() => eliminarHorario(index)}>
                  <i className="bi bi-trash"></i>
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <div className="empty-state">No tienes horarios registrados.</div>
        )}
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        titulo="Agregar Nuevo Horario"
      >
        <div className="formulario-modal">
          <div className="campo-grupo">
            <label>Escoger Fecha:</label>
            <input 
              type="date" 
              className="horarios-input"
              value={fecha} 
              onChange={(e) => setFecha(e.target.value)}
            />
          </div>

          <div className="campo-grupo-doble">
            <div className="campo-grupo">
              <label>Hora Inicio:</label>
              <input 
                type="time" 
                className="horarios-input"
                value={horaInicio} 
                onChange={(e) => setHoraInicio(e.target.value)}
              />
            </div>
            
            <div className="campo-grupo">
              <label>Hora Fin:</label>
              <input type="time" className="horarios-input" value={horaFin} onChange={(e) => setHoraFin(e.target.value)}
              />
            </div>
          </div>
          <button className="btn-agregar-horario btn-bloque" onClick={agregarHorario}>Guardar Horario</button>
        </div>
      </Modal>
    </section>
  );
}